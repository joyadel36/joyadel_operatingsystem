#!/bin/bash

echo "please enter number" 
read num
rev=0
sum=0
count=0
while [ 0 ]
do 
dig=`expr $num % 10`
sum=`expr $sum + $dig`
rev=`expr $rev \* 10 + $dig`
num=`expr $num - $dig`
num=`expr $num / 10`
count=$( expr $count + 1 )
if [ $num -eq 0 ]
then 
break
fi
done
echo "Reverse number = $rev"
echo "Sum of digits = $sum"
echo "Average = `echo $sum / $count | bc -l`" 
