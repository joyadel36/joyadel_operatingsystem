#!/bin/bash
while [ 0 ]
do
echo "please enter a positive integer 1 "
read num1
echo "please enter a positive integer 2"
read num2
if [[ $num1 -lt 0 || $num2 -lt 0 ]]
then
echo "ERROR"
else
sum=`expr $num1 + $num2`
echo " average = `echo $sum / 2 | bc -l` "
break
fi
done
