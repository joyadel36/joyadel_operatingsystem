#!/bin/bash
sum=0
count=0
while [ 0 ]
do
echo "please enter a positive integer"
read num
if [ $num -lt 0 ]
then 
echo "ERROR"
elif [ $num -eq 0 ]
then
break
else
sum=`expr $sum + $num`
count=$( expr $count + 1 )
fi
done
if [ $sum -ne 0 ]
then
echo " average = `echo $sum / $count | bc -l` "
else
echo " average = 0 "
fi
