#!/bin/bash
echo " please enter your salary "
read salary
if [ $salary -ge 2000 ]
then 
echo " salary after tax reduction = `echo $salary \* 85 /100 | bc -l`"
elif [[ $salary -lt 2000 && $salary -ge 1000 ]]
then
echo " salary after tax reduction = `echo $salary \* 90 /100 | bc -l` "
else
echo " salary after tax reduction = $salary "
fi

