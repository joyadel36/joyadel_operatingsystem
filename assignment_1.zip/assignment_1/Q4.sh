#!/bin/bash
echo "please enter a number "
read num
echo "please enter a power"
read pow
res=1
if [ $pow -gt 0 ]
then
for (( x=0 ; x<$pow ; x++ ))
do
res=$(expr $res \* $num) 
done
echo "result = $res"
else
echo you shoud entr a positive power 
fi
