#!/bin/bash
echo "please enter number of second"
read sec;
h=`expr $sec / 60 / 60` 
h2=`expr $h \* 60 \* 60`
m=`expr $sec - $h2`
m1=`expr $m / 60`
m2=`expr $m1 \* 60`
sec1=`expr $sec - $h2 - $m2`
echo "$h : $m1 : $sec1" 
