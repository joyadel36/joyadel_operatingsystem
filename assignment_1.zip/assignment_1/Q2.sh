#!/bin/bash
echo " please enter a temperature in degrees Celsius "
read tempc 
echo "temperature in degrees Fahrenheit = `echo 1.8 \* $tempc + 32 | bc -l`"
