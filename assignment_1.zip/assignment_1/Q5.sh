#!/bin/bash
echo "please enter a number "
read num
res=1
count=2 
while [ $count -lt  $num ]
do
res=$( expr $num % $count )
if [ $res -eq 0 ]
then
break
else 
count=$( expr $count + 1  )
fi
done
if [[ $res -ne 0 && $num -ne 1 ]]
then
echo " $num is prime "
else
echo " $num is not  prime "
fi

